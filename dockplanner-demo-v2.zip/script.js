
document.getElementById('root').innerHTML = '<h1 style="text-align:center;margin-top:20vh;">Dockplanner Demo</h1><p style="text-align:center;">Login: DemoAdmin123 / DemoAdmin123</p>';
